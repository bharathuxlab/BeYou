
import React, { useState, useEffect, useRef } from 'react';
import { LiveClient } from '../services/liveClient';
import { Button } from './Button';
import { gradeInterview, getCompanyOverview } from '../services/geminiService';
import { InterviewReport } from '../types';
import { Mic, Zap, Briefcase, AlertCircle, Play, Pause, Check, Lightbulb, User, Bot, Loader2, Signal, Globe, ExternalLink, Target, ArrowRight } from 'lucide-react';

interface LiveViewProps {
  systemInstruction?: string;
  companyName?: string;
  mode?: 'COACH' | 'INTERVIEW';
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

// Utility to render text with bold support and strip markdown
const formatText = (text: string) => {
  if (!text) return null;
  return text.split(/(\*\*.*?\*\*)/).map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-bold">{part.slice(2, -2)}</strong>;
    }
    return part;
  });
};

export const LiveView: React.FC<LiveViewProps> = ({ 
  systemInstruction, 
  companyName,
  mode = 'COACH' 
}) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [report, setReport] = useState<InterviewReport | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  
  const liveClientRef = useRef<LiveClient | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const hasAttemptedAutoStart = useRef(false);

  // Auto-scroll chat
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatHistory]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (liveClientRef.current) liveClientRef.current.disconnect();
    };
  }, []);

  const handleTranscript = (sender: 'user' | 'model', text: string, mode: 'append' | 'replace') => {
    setChatHistory(prev => {
      const last = prev[prev.length - 1];
      if (last && last.role === sender) {
        const newHistory = [...prev];
        const lastIndex = newHistory.length - 1;
        if (mode === 'replace') {
          newHistory[lastIndex] = { ...last, text: text };
        } else {
          newHistory[lastIndex] = { ...last, text: last.text + text };
        }
        return newHistory;
      } 
      return [...prev, { role: sender, text }];
    });
  };

  const handleConnectionLost = () => {
    setIsConnected(false);
    setIsConnecting(false);
  };

  const toggleConnection = async () => {
    setError(null);
    
    if (isConnected) {
      if (liveClientRef.current) liveClientRef.current.disconnect();
      setIsConnected(false);
      setIsConnecting(false);
      return;
    }

    setIsConnecting(true);
    
    try {
      liveClientRef.current = new LiveClient();
      await liveClientRef.current.connect(
        handleConnectionLost, 
        systemInstruction,
        handleTranscript
      );
      
      setIsConnected(true);
      setIsConnecting(false);
      
      // Kickstart Interview
      if (mode === 'INTERVIEW' && liveClientRef.current) {
        setTimeout(() => {
          liveClientRef.current?.sendText("I am ready. Please introduce yourself and start the interview.");
        }, 500);
      }

    } catch (e: any) {
      console.error(e);
      setError("Could not connect. Please check permissions.");
      setIsConnecting(false);
      setIsConnected(false);
    }
  };

  const handleFinishAndAnalyze = async () => {
    setAnalyzing(true);
    if (liveClientRef.current) liveClientRef.current.disconnect();
    setIsConnected(false);
    
    // Parallel fetch: Grade Interview AND Get Company Data (if company exists)
    const gradePromise = gradeInterview(chatHistory);
    const companyPromise = companyName ? getCompanyOverview(companyName) : Promise.resolve(null);

    const [gradeResult, companyResult] = await Promise.all([gradePromise, companyPromise]);

    if (gradeResult) {
      setReport({
        ...gradeResult,
        companyOverview: companyResult?.text,
        companySources: companyResult?.sources
      });
    }
    setAnalyzing(false);
  };

  // --- REPORT VIEW ---
  if (report) {
    const scoreColor = report.score >= 80 ? 'text-green-500' : report.score >= 50 ? 'text-orange-500' : 'text-red-500';
    const scoreBg = report.score >= 80 ? 'bg-green-50' : report.score >= 50 ? 'bg-orange-50' : 'bg-red-50';

    return (
      <div className="w-full max-w-5xl bg-white/90 backdrop-blur-xl md:rounded-3xl shadow-2xl p-0 h-full md:h-[700px] flex flex-col animate-scale-in overflow-hidden border border-white/50">
        
        {/* Header with Score */}
        <div className="flex items-center justify-between p-8 border-b border-gray-100 bg-white/50">
           <div>
             <h2 className="text-3xl font-bold text-gray-900 display-font">Performance Review</h2>
             <p className="text-gray-500 mt-1 flex items-center gap-2">
               <Briefcase size={14} /> {companyName || 'Technical Interview'}
             </p>
           </div>
           
           <div className={`flex flex-col items-center justify-center w-20 h-20 rounded-full border-4 border-white shadow-lg ${scoreBg}`}>
              <span className={`text-2xl font-bold ${scoreColor}`}>{report.score}</span>
           </div>
        </div>
        
        <div className="flex-1 overflow-y-auto no-scrollbar p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
           
           {/* Column 1: Feedback */}
           <div className="space-y-6">
             <div className="bg-green-50/50 rounded-2xl p-6 border border-green-100">
                <h3 className="text-sm font-bold text-green-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Check size={18} className="text-green-600" /> Strengths
                </h3>
                <div className="space-y-3">
                   {report.strengths.map((point, i) => (
                      <div key={i} className="flex gap-3 text-gray-800 text-sm leading-relaxed bg-white p-3 rounded-xl shadow-sm border border-green-50/50">
                         <span className="w-2 h-2 bg-green-400 rounded-full mt-1.5 shrink-0"></span>
                         {formatText(point)}
                      </div>
                   ))}
                </div>
             </div>

             <div className="bg-orange-50/50 rounded-2xl p-6 border border-orange-100">
                <h3 className="text-sm font-bold text-orange-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Lightbulb size={18} className="text-orange-600" /> Areas to Improve
                </h3>
                <div className="space-y-3">
                   {report.improvements.map((point, i) => (
                      <div key={i} className="flex gap-3 text-gray-800 text-sm leading-relaxed bg-white p-3 rounded-xl shadow-sm border border-orange-50/50">
                         <span className="w-2 h-2 bg-orange-400 rounded-full mt-1.5 shrink-0"></span>
                         {formatText(point)}
                      </div>
                   ))}
                </div>
             </div>
           </div>

           {/* Column 2: Company Intelligence & Actions */}
           <div className="space-y-6">
             
             {/* Company Overview (Search Result) */}
             <div className="bg-blue-50/50 rounded-2xl p-6 border border-blue-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100 rounded-full -mr-16 -mt-16 blur-xl opacity-50"></div>
                <h3 className="text-sm font-bold text-blue-700 uppercase tracking-wider mb-4 flex items-center gap-2 relative z-10">
                  <Globe size={18} className="text-blue-600" /> Company Intelligence
                </h3>
                
                {report.companyOverview ? (
                  <div className="text-sm text-gray-700 leading-relaxed space-y-2 relative z-10">
                    <div className="markdown-prose">{formatText(report.companyOverview)}</div>
                    
                    {report.companySources && report.companySources.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-blue-100">
                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-2">Sources</p>
                        <div className="flex flex-wrap gap-2">
                          {report.companySources.map((s, idx) => (
                            <a key={idx} href={s.uri} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-[10px] bg-white px-2 py-1 rounded-md border border-blue-100 text-blue-600 hover:underline">
                              {s.title} <ExternalLink size={8} />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 italic">No specific company data available.</p>
                )}
             </div>

             <div className="bg-purple-50/50 rounded-2xl p-6 border border-purple-100">
                <h3 className="text-sm font-bold text-purple-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Target size={18} className="text-purple-600" /> Recommended Actions
                </h3>
                <div className="space-y-2">
                   {report.suggestedActions.map((action, i) => (
                      <div key={i} className="flex items-start gap-3 text-gray-800 text-sm leading-relaxed p-2">
                         <div className="bg-white p-1 rounded-md shadow-sm border border-purple-100 shrink-0">
                           <ArrowRight size={12} className="text-purple-500" />
                         </div>
                         {formatText(action)}
                      </div>
                   ))}
                </div>
             </div>

           </div>
        </div>

        <div className="p-6 border-t border-gray-100 bg-white/80 backdrop-blur-md">
          <Button onClick={() => setReport(null)} fullWidth>
             Start New Session
          </Button>
        </div>
      </div>
    );
  }

  // --- LIVE INTERFACE ---
  return (
    <div className="w-full max-w-6xl bg-white/80 backdrop-blur-md md:rounded-3xl shadow-2xl p-0 h-full md:h-[700px] flex flex-col md:flex-row overflow-hidden border border-white/50 relative">
      
      {/* Loading / Connecting Overlay */}
      {(isConnecting || analyzing) && (
        <div className="absolute inset-0 z-[60] flex flex-col items-center justify-center bg-white/80 backdrop-blur-md animate-fade-in">
          <Loader2 className="w-12 h-12 text-black animate-spin mb-4" />
          <p className="text-gray-600 font-medium animate-pulse">
            {analyzing ? 'Compiling Performance Report...' : 'Connecting to Neural Network...'}
          </p>
        </div>
      )}

      {/* Start Prompt Overlay */}
      {!isConnected && !isConnecting && !report && !analyzing && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-white/60 backdrop-blur-sm animate-fade-in">
           <div className="bg-white p-8 rounded-3xl shadow-2xl text-center max-w-sm border border-gray-100 ring-4 ring-gray-50 transform transition-all hover:scale-105">
              <div className="w-20 h-20 bg-gradient-to-tr from-gray-900 to-gray-700 text-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-gray-200">
                {mode === 'INTERVIEW' ? <Briefcase size={36} /> : <Mic size={36} />}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 display-font mb-2">
                {mode === 'INTERVIEW' ? 'Interview Ready' : 'Start Session'}
              </h3>
              <p className="text-gray-500 mb-8 leading-relaxed text-sm">
                {error ? <span className="text-red-500 flex items-center justify-center gap-1"><AlertCircle size={14}/> {error}</span> : "Microphone access required. Find a quiet space for the best experience."}
              </p>
              <Button onClick={toggleConnection} fullWidth className="h-14 text-lg shadow-xl shadow-indigo-200 bg-black text-white hover:bg-gray-800 transition-all">
                 {mode === 'INTERVIEW' ? 'Begin Interview' : 'Start Coaching'}
              </Button>
           </div>
        </div>
      )}

      {/* Left Panel: Visualizer */}
      <div className="w-full md:w-80 bg-gray-50/50 flex flex-col items-center justify-between md:border-r border-b md:border-b-0 border-gray-200 p-6 relative overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-0 left-0 w-full h-full opacity-40 pointer-events-none overflow-hidden">
            <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-100/40 via-transparent to-transparent animate-spin-slow"></div>
        </div>

        <div className="relative z-10 text-center w-full mt-4">
           {isConnected && (
             <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-100/50 border border-green-200 mb-4 animate-fade-in">
               <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-green-700">Live Audio</span>
             </div>
           )}
           <h2 className="text-xl font-bold text-gray-900 display-font">
            {mode === 'INTERVIEW' ? 'Interviewer' : 'Focus Coach'}
           </h2>
           {companyName && <p className="text-xs text-gray-500 mt-1">{companyName}</p>}
        </div>

        {/* Dynamic Visualizer Circle */}
        <div className="relative z-10 flex-1 flex items-center justify-center w-full my-4">
          <div className={`relative flex items-center justify-center transition-all duration-1000 ${isConnected ? 'scale-110' : 'scale-95 opacity-50 grayscale'}`}>
            {/* Outer Ripples */}
            {isConnected && (
               <>
                 <div className="absolute inset-0 rounded-full border border-indigo-500/20 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                 <div className="absolute inset-0 rounded-full border border-indigo-500/10 animate-[ping_4s_cubic-bezier(0,0,0.2,1)_infinite] delay-700"></div>
               </>
            )}
            
            {/* Main Orb */}
            <div className={`relative z-10 w-32 h-32 rounded-full shadow-2xl flex items-center justify-center border-4 border-white bg-gradient-to-br ${mode === 'INTERVIEW' ? 'from-slate-800 to-black' : 'from-indigo-500 to-purple-600'} transition-colors duration-500`}>
               {isConnected ? (
                  <div className="flex gap-1 items-end h-8">
                     <div className="w-1.5 bg-white rounded-full animate-[music-bar_1s_ease-in-out_infinite]"></div>
                     <div className="w-1.5 bg-white rounded-full animate-[music-bar_1.2s_ease-in-out_infinite_0.1s]"></div>
                     <div className="w-1.5 bg-white rounded-full animate-[music-bar_0.8s_ease-in-out_infinite_0.2s]"></div>
                     <div className="w-1.5 bg-white rounded-full animate-[music-bar_1.1s_ease-in-out_infinite_0.3s]"></div>
                  </div>
               ) : (
                  mode === 'INTERVIEW' ? <Briefcase className="text-white w-12 h-12" /> : <Mic className="text-white w-12 h-12" />
               )}
            </div>
          </div>
        </div>

        <div className="relative z-10 w-full space-y-3 hidden md:block">
          <Button 
            onClick={toggleConnection} 
            fullWidth
            variant={isConnected ? 'secondary' : 'primary'}
            disabled={isConnecting}
            className="h-12 text-sm shadow-md"
          >
            {isConnected ? <span className="flex items-center gap-2"><Pause size={16}/> End Session</span> : <span className="flex items-center gap-2"><Play size={16}/> Resume</span>}
          </Button>
          
          {mode === 'INTERVIEW' && chatHistory.length > 2 && (
             <Button 
               onClick={handleFinishAndAnalyze} 
               fullWidth
               className="bg-gray-900 hover:bg-black text-white border-none shadow-lg h-12 text-sm"
               disabled={analyzing}
             >
               Finish & Assessment
             </Button>
          )}
        </div>
      </div>

      {/* Right Panel: Transcript */}
      <div className="flex-1 flex flex-col bg-white/60 relative h-full">
        <div className="p-4 border-b border-gray-100 bg-white/40 backdrop-blur-md flex justify-between items-center sticky top-0 z-20">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
              <Signal size={14} className="text-indigo-500" /> Live Transcript
            </span>
            <div className="text-xs text-gray-400 font-medium">
               {chatHistory.length > 0 ? `${chatHistory.length} turns` : 'Listening...'}
            </div>
        </div>
        
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth mb-24 md:mb-0">
          {chatHistory.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-40">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                 <Mic size={28} className="text-gray-400" />
              </div>
              <p className="text-sm font-medium text-gray-600">Conversation Empty</p>
              <p className="text-xs mt-1 text-gray-400 max-w-xs">
                 The transcript will appear here in real-time.
              </p>
            </div>
          ) : (
            chatHistory.map((msg, idx) => (
              <div key={idx} className={`group flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in-up`}>
                <div className={`flex max-w-[85%] md:max-w-[75%] gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                   
                   <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold border shadow-sm mt-1 transition-transform group-hover:scale-105 ${
                     msg.role === 'user' 
                       ? 'bg-black text-white' 
                       : 'bg-indigo-600 text-white'
                   }`}>
                      {msg.role === 'user' ? <User size={14}/> : <Bot size={14}/>}
                   </div>

                   <div className={`p-4 rounded-2xl text-[15px] leading-relaxed shadow-sm transition-all ${
                     msg.role === 'user' 
                       ? 'bg-white text-gray-800 rounded-tr-sm border border-gray-100' 
                       : 'bg-white text-gray-800 rounded-tl-sm border border-gray-100'
                   }`}>
                      {formatText(msg.text)}
                   </div>

                </div>
              </div>
            ))
          )}
        </div>
        
        {/* Mobile controls */}
        <div className="md:hidden p-4 border-t border-gray-100 bg-white/80 backdrop-blur fixed bottom-24 left-4 right-4 z-40 flex gap-2 rounded-2xl shadow-xl">
             <Button 
               onClick={toggleConnection} 
               fullWidth
               variant={isConnected ? 'secondary' : 'primary'}
               className="h-12 shadow-none border-gray-200"
             >
               {isConnected ? <Pause size={20} /> : <Play size={20} />}
             </Button>
             {mode === 'INTERVIEW' && (
                <Button onClick={handleFinishAndAnalyze} className="h-12 bg-black text-white shadow-none w-auto px-6">
                  <Check size={20} />
                </Button>
             )}
        </div>

      </div>

    </div>
  );
};
