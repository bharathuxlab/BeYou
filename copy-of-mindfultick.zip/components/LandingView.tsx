
import React from 'react';
import { Button } from './Button';
import { Timer, Briefcase, Zap, ArrowRight, Star, Hexagon, FileText, CheckCircle } from 'lucide-react';

interface LandingViewProps {
  onEnter: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({ onEnter }) => {
  return (
    <div className="w-full min-h-screen flex flex-col relative overflow-y-auto bg-transparent">
      
      {/* Hero Section */}
      <div className="flex-grow flex flex-col items-center justify-center text-center p-8 z-10 max-w-5xl mx-auto mt-8 md:mt-16">
        
        <div className="mb-8 animate-fade-in-up">
           <div className="inline-flex items-center gap-2 bg-white/60 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/50 shadow-sm ring-1 ring-gray-100/50">
             <Star size={12} className="text-yellow-500 fill-yellow-500" />
             <span className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">AI-Enhanced Productivity</span>
           </div>
        </div>
        
        <h1 className="text-5xl md:text-8xl font-bold text-gray-900 mb-6 display-font tracking-tighter leading-[0.9] animate-fade-in-up animation-delay-100 drop-shadow-sm">
          Mindful<span className="text-transparent bg-clip-text bg-gradient-to-br from-indigo-600 to-violet-400">Tick</span>
        </h1>
        
        <p className="text-lg md:text-xl text-gray-500 max-w-xl mb-10 leading-relaxed font-light animate-fade-in-up animation-delay-200 tracking-tight">
          A minimalistic suite for deep work and career acceleration.
          <br className="hidden md:block"/>
          <span className="text-gray-400">Psychology-based timers. Real-time coaching. Resume Intelligence.</span>
        </p>

        <div className="animate-fade-in-up animation-delay-300 relative group z-20">
          <div className="absolute -inset-1 bg-gradient-to-r from-gray-900 to-gray-700 rounded-full blur opacity-25 group-hover:opacity-40 transition duration-200"></div>
          <Button onClick={onEnter} className="relative px-10 py-5 text-lg bg-black text-white hover:bg-gray-800 transition-all hover:scale-[1.02] active:scale-[0.98] rounded-full border-0 shadow-2xl">
             Launch App <ArrowRight size={20} className="ml-2" />
          </Button>
        </div>
      </div>

      {/* Bento Grid Features */}
      <div className="w-full z-10 px-4 md:px-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-7xl mx-auto">
          
          {/* Card 1: Flow Timer */}
          <div className="relative overflow-hidden p-6 rounded-[2rem] bg-white/40 backdrop-blur-xl border border-white/60 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-default">
             <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-100/60 rounded-full blur-2xl -mr-8 -mt-8"></div>
             <div className="relative z-10">
               <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm mb-4 text-indigo-600 ring-1 ring-gray-100">
                  <Timer size={20} />
               </div>
               <h3 className="text-base font-bold text-gray-900 mb-1">Flow Timer</h3>
               <p className="text-xs text-gray-500 leading-relaxed font-medium">
                 Psychological countdowns designed to break procrastination loops.
               </p>
             </div>
          </div>

          {/* Card 2: AI Coach */}
          <div className="relative overflow-hidden p-6 rounded-[2rem] bg-white/40 backdrop-blur-xl border border-white/60 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-default">
             <div className="absolute top-0 right-0 w-24 h-24 bg-orange-100/60 rounded-full blur-2xl -mr-8 -mt-8"></div>
             <div className="relative z-10">
               <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm mb-4 text-orange-500 ring-1 ring-gray-100">
                  <Zap size={20} />
               </div>
               <h3 className="text-base font-bold text-gray-900 mb-1">Voice Coach</h3>
               <p className="text-xs text-gray-500 leading-relaxed font-medium">
                 Real-time audio motivation that adapts to your mood instantly.
               </p>
             </div>
          </div>

          {/* Card 3: Resume Tailor */}
          <div className="relative overflow-hidden p-6 rounded-[2rem] bg-white/40 backdrop-blur-xl border border-white/60 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-default">
             <div className="absolute top-0 right-0 w-24 h-24 bg-purple-100/60 rounded-full blur-2xl -mr-8 -mt-8"></div>
             <div className="relative z-10">
               <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm mb-4 text-purple-600 ring-1 ring-gray-100">
                  <FileText size={20} />
               </div>
               <h3 className="text-base font-bold text-gray-900 mb-1">ATS Tailor</h3>
               <p className="text-xs text-gray-500 leading-relaxed font-medium">
                 Rewrite your CV for specific jobs with ATS-proof plain text formatting.
               </p>
             </div>
          </div>

          {/* Card 4: Interview Sim */}
          <div className="relative overflow-hidden p-6 rounded-[2rem] bg-white/40 backdrop-blur-xl border border-white/60 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-default">
             <div className="absolute top-0 right-0 w-24 h-24 bg-teal-100/60 rounded-full blur-2xl -mr-8 -mt-8"></div>
             <div className="relative z-10">
               <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm mb-4 text-teal-600 ring-1 ring-gray-100">
                  <Briefcase size={20} />
               </div>
               <h3 className="text-base font-bold text-gray-900 mb-1">Interview Sim</h3>
               <p className="text-xs text-gray-500 leading-relaxed font-medium">
                 Practice high-stakes interviews with instant scoring & company intel.
               </p>
             </div>
          </div>

        </div>
        
        {/* Footer Meta */}
        <div className="w-full text-center py-6 mt-2">
           <div className="text-[10px] text-gray-400 font-mono tracking-widest uppercase flex justify-center items-center gap-2 opacity-60">
             <Hexagon size={10} /> v2.0 • MindfulTick
           </div>
        </div>
      </div>
    </div>
  );
};
