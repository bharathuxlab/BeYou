import React, { useState } from 'react';
import { HistoryItem, CATEGORY_COLORS, CATEGORY_EMOJIS } from '../types';
import { Button } from './Button';
import { Sparkles, Clock, Calendar } from 'lucide-react';
import { analyzeHistory } from '../services/geminiService';

interface StatsViewProps {
  history: HistoryItem[];
}

// Utility to render text with bold support and strip markdown
const formatText = (text: string) => {
  return text.split(/(\*\*.*?\*\*)/).map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-bold">{part.slice(2, -2)}</strong>;
    }
    return part;
  });
};

export const StatsView: React.FC<StatsViewProps> = ({ history }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const totalMinutes = history.reduce((acc, curr) => acc + curr.durationMinutes, 0);

  const handleAnalyze = async () => {
    setLoading(true);
    const result = await analyzeHistory(history);
    setInsight(result);
    setLoading(false);
  };

  const formatDate = (ts?: number) => {
    if (!ts) return '';
    return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  return (
    <div className="w-full max-w-md bg-white rounded-3xl shadow-soft p-6 h-[600px] flex flex-col animate-fade-in-up overflow-hidden relative">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 display-font">Your Flow</h2>
        <div className="bg-gray-100 px-3 py-1 rounded-full text-xs font-bold text-gray-500">
          {history.length} Sessions
        </div>
      </div>

      {/* Hero Card */}
      <div className="bg-black text-white p-6 rounded-2xl mb-6 shadow-lg relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gray-800 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-110 transition-transform duration-500"></div>
        <div className="relative z-10">
          <p className="text-gray-400 text-sm font-medium uppercase tracking-wider mb-1">Total Focus Time</p>
          <div className="text-4xl font-bold display-font flex items-baseline gap-2">
            {totalMinutes} <span className="text-xl text-gray-500 font-normal">min</span>
          </div>
        </div>
      </div>

      {/* AI Insight Section */}
      <div className="mb-6">
        {!insight && (
          <Button 
            onClick={handleAnalyze} 
            fullWidth 
            disabled={history.length === 0 || loading}
            className={history.length === 0 ? "opacity-50" : ""}
          >
            {loading ? "Consulting the Oracle..." : (
              <span className="flex items-center gap-2">
                <Sparkles size={18} /> Analyze My Psych Profile
              </span>
            )}
          </Button>
        )}

        {insight && (
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-5 rounded-2xl border border-indigo-100 animate-fade-in">
             {/* Simple markdown parsing for the title */}
            <h3 className="text-indigo-900 font-bold text-lg mb-2 flex items-center gap-2">
              <Sparkles size={16} className="text-indigo-500" />
              {formatText(insight.split('\n')[0].replace('## ', ''))}
            </h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              {formatText(insight.split('\n').slice(1).join('\n').trim())}
            </p>
          </div>
        )}
      </div>

      {/* History List */}
      <div className="flex-1 overflow-y-auto no-scrollbar -mx-2 px-2">
        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 sticky top-0 bg-white py-2">Recent History</h3>
        {history.length === 0 ? (
          <div className="text-center py-10 text-gray-400">
            <Clock size={40} className="mx-auto mb-2 opacity-20" />
            <p>No sessions yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {history.map((item) => (
              <div key={item.id} className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-100 transition-hover hover:bg-gray-100">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-sm ${CATEGORY_COLORS[item.category]}`}>
                  {CATEGORY_EMOJIS[item.category]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 truncate text-sm">{item.intention || item.category}</p>
                  <p className="text-xs text-gray-500">{formatDate(item.completedAt)} • {item.durationMinutes} min</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};