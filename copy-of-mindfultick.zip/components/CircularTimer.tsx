
import React from 'react';

interface CircularTimerProps {
  percentage: number;
  colorClass: string;
  size?: number;
  strokeWidth?: number;
  children?: React.ReactNode;
}

export const CircularTimer: React.FC<CircularTimerProps> = ({ 
  percentage, 
  colorClass, 
  size = 300, 
  strokeWidth = 12,
  children
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const dashoffset = circumference - (percentage / 100) * circumference;

  // Extract the raw color from the class for the drop shadow (simplified mapping)
  const getColorHex = (cls: string) => {
    if (cls.includes('indigo')) return '#5856D6';
    if (cls.includes('pink')) return '#FF2D55';
    if (cls.includes('orange')) return '#FF9500';
    if (cls.includes('blue')) return '#007AFF';
    if (cls.includes('teal')) return '#30B0C7';
    return '#5856D6';
  };

  const activeColor = getColorHex(colorClass);

  // Calculate position of the "Thumb" indicator
  // The SVG is rotated -90deg, so 0 radians is at the top (12 o'clock relative to screen)
  // We need to calculate based on the percentage 0-100.
  // 100% = Full circle.
  // Note: strokeDashoffset moves counter-clockwise usually, but with our setup:
  // We are filling it. Let's align the thumb with the stroke.
  // Stroke starts at 12 o'clock and fills clockwise (because dashoffset reduces).
  const angleInRadians = (percentage / 100) * 2 * Math.PI;
  
  // Center is size/2
  const cx = size / 2;
  const cy = size / 2;
  
  // Parametric circle equation (Offset by -PI/2 is handled by CSS rotation, so we calculate standard circle here)
  const thumbX = cx + radius * Math.cos(angleInRadians);
  const thumbY = cy + radius * Math.sin(angleInRadians);

  return (
    <div className="relative flex items-center justify-center">
      {/* Outer Pulse Ring */}
      <div className={`absolute inset-0 rounded-full border-2 opacity-20 scale-100 animate-pulse-slow ${colorClass.replace('bg-', 'border-')}`}></div>
      
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="transform -rotate-90 transition-transform duration-500 ease-in-out"
      >
        {/* Background Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          className="fill-none stroke-gray-100"
        />
        
        {/* Progress Circle - Fast duration-75 for smooth updates from App.tsx */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          className="fill-none transition-all duration-75 ease-linear"
          stroke={activeColor}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashoffset}
          style={{ 
            filter: `drop-shadow(0px 0px 8px ${activeColor}80)` 
          }}
        />

        {/* Glowing Tip/Knob */}
        <circle
           cx={thumbX}
           cy={thumbY}
           r={strokeWidth * 0.8}
           fill="white"
           className="transition-all duration-75 ease-linear shadow-sm"
           style={{ 
             filter: `drop-shadow(0px 0px 4px ${activeColor})`
           }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {children}
      </div>
      
      <style>{`
        @keyframes pulse-slow {
          0%, 100% { transform: scale(1); opacity: 0.1; }
          50% { transform: scale(1.05); opacity: 0.2; }
        }
        .animate-pulse-slow {
          animation: pulse-slow 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
