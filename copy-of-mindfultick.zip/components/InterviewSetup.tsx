
import React, { useState } from 'react';
import { Button } from './Button';
import { analyzeInterviewContext } from '../services/geminiService';
import { InterviewAnalysis } from '../types';
import { Briefcase, FileText, ArrowRight, CheckCircle, Target, Zap, AlertTriangle, Building } from 'lucide-react';

interface InterviewSetupProps {
  onStartInterview: (systemInstruction: string, companyName: string) => void;
}

export const InterviewSetup: React.FC<InterviewSetupProps> = ({ onStartInterview }) => {
  const [jd, setJd] = useState('');
  const [resume, setResume] = useState('');
  const [analysis, setAnalysis] = useState<InterviewAnalysis | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!jd.trim() || !resume.trim()) return;
    setLoading(true);
    const result = await analyzeInterviewContext(jd, resume);
    setAnalysis(result);
    setLoading(false);
  };

  const handleStart = () => {
    if (!analysis) return;

    // Construct a specific system instruction for the Live API
    const instruction = `
      You are an expert technical interviewer for this specific role.
      
      JOB DESCRIPTION SUMMARY: ${analysis.coreNeed}
      COMPANY: ${analysis.companyName}
      KEY CANDIDATE STRENGTH: ${analysis.strongestMatch}
      AREA TO PROBE (GAP): ${analysis.gapToProbe}
      
      INSTRUCTIONS:
      1. CRITICAL: You must speak FIRST immediately when the connection is established. Do not wait for the user.
      2. Your first message must be: "Hello! I've reviewed your resume. I see you're applying for the role at ${analysis.companyName}. Do I have your consent to begin the interview?"
      3. Wait for the candidate to say "Yes".
      4. Proceed to ask questions one by one.
      5. Focus your questions on the identified gap: ${analysis.gapToProbe}.
      6. Keep your responses professional but concise (under 20 seconds).
    `;
    onStartInterview(instruction, analysis.companyName);
  };

  return (
    <div className="w-full max-w-4xl bg-white rounded-3xl shadow-soft p-6 h-[600px] flex flex-col animate-fade-in-up overflow-hidden">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 display-font">Interview Prep</h2>
        <div className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
          <Zap size={12} fill="currentColor" /> AI Analysis
        </div>
      </div>

      {!analysis ? (
        <div className="flex-1 flex flex-col gap-4 overflow-y-auto no-scrollbar">
          <div className="flex flex-col md:flex-row gap-4 h-full">
            <div className="flex-1 flex flex-col">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                <Briefcase size={14} /> Job Description
              </label>
              <textarea
                className="flex-1 w-full bg-gray-50 rounded-xl p-4 text-sm border-none focus:ring-2 focus:ring-black/5 resize-none placeholder-gray-400"
                placeholder="Paste the job description here..."
                value={jd}
                onChange={(e) => setJd(e.target.value)}
              />
            </div>
            <div className="flex-1 flex flex-col">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                <FileText size={14} /> Your Resume
              </label>
              <textarea
                className="flex-1 w-full bg-gray-50 rounded-xl p-4 text-sm border-none focus:ring-2 focus:ring-black/5 resize-none placeholder-gray-400"
                placeholder="Paste your resume details here..."
                value={resume}
                onChange={(e) => setResume(e.target.value)}
              />
            </div>
          </div>
          <Button 
            onClick={handleAnalyze} 
            disabled={!jd || !resume || loading}
            fullWidth
          >
            {loading ? "Analyzing Context..." : "Analyze & Plan Interview"}
          </Button>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pr-1">
            
            {/* Analysis Cards */}
            <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-5">
              <h3 className="text-indigo-900 font-bold mb-2 flex items-center gap-2">
                <Target className="text-indigo-500" size={20} /> The Core Need
              </h3>
              <p className="text-indigo-800 text-sm leading-relaxed">{analysis.coreNeed}</p>
            </div>

            <div className="bg-gray-50 border border-gray-100 rounded-2xl p-5">
               <h3 className="text-gray-800 font-bold mb-2 flex items-center gap-2">
                 <Building className="text-gray-500" size={20} /> Target Company
               </h3>
               <p className="text-gray-700 text-sm leading-relaxed">{analysis.companyName}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 border border-green-100 rounded-2xl p-5">
                <h3 className="text-green-800 font-bold mb-2 flex items-center gap-2">
                  <CheckCircle className="text-green-500" size={20} /> Your Strength
                </h3>
                <p className="text-green-700 text-sm leading-relaxed">{analysis.strongestMatch}</p>
              </div>

              <div className="bg-orange-50 border border-orange-100 rounded-2xl p-5">
                <h3 className="text-orange-800 font-bold mb-2 flex items-center gap-2">
                  <AlertTriangle className="text-orange-500" size={20} /> The Gap
                </h3>
                <p className="text-orange-700 text-sm leading-relaxed">{analysis.gapToProbe}</p>
              </div>
            </div>

          </div>

          <div className="flex gap-3 mt-6 pt-4 border-t border-gray-100">
             <Button variant="secondary" onClick={() => setAnalysis(null)} className="flex-1">
               Edit Context
             </Button>
             <Button onClick={handleStart} className="flex-[2] bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200">
               Start Live Interview <ArrowRight size={18} />
             </Button>
          </div>
        </div>
      )}
    </div>
  );
};
