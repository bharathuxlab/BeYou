import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '',
  ...props 
}) => {
  const baseStyle = "active:scale-95 transition-transform duration-200 font-semibold py-4 px-6 rounded-2xl flex items-center justify-center gap-2 select-none shadow-sm";
  
  const variants = {
    primary: "bg-black text-white hover:bg-gray-900 shadow-lg shadow-gray-200",
    secondary: "bg-white text-gray-900 border border-gray-100 hover:bg-gray-50",
    ghost: "bg-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-100/50",
    danger: "bg-red-50 text-red-500 hover:bg-red-100"
  };

  return (
    <button 
      className={`${baseStyle} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};