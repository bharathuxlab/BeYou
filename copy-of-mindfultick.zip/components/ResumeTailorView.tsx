
import React, { useState, useRef } from 'react';
import { Button } from './Button';
import { tailorResume } from '../services/geminiService';
import { FileText, Wand2, Briefcase, Download, Printer, Copy, Check } from 'lucide-react';

export const ResumeTailorView: React.FC = () => {
  const [jd, setJd] = useState('');
  const [resume, setResume] = useState('');
  const [newResume, setNewResume] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const printRef = useRef<HTMLDivElement>(null);

  const handleTailor = async () => {
    if (!jd.trim() || !resume.trim()) return;
    setLoading(true);
    const result = await tailorResume(jd, resume);
    // Clean potential markdown artifacts to ensure plain text
    const cleanResult = result
      .replace(/\*\*/g, '')
      .replace(/__/g, '')
      .replace(/###/g, '')
      .replace(/^# /gm, '')
      .replace(/`/g, '');
      
    setNewResume(cleanResult);
    setLoading(false);
  };

  const handleCopy = () => {
    if (newResume) {
      navigator.clipboard.writeText(newResume);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadTxt = () => {
    if (!newResume) return;
    const element = document.createElement("a");
    const file = new Blob([newResume], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "Optimized_Resume_ATS.txt";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handlePrint = () => {
    if (!newResume) return;
    
    const w = window.open('', '_blank');
    if (w) {
        // Inject Inter font and set precise print styles with word breaking
        w.document.write(`
          <html>
            <head>
              <title>Resume Preview</title>
              <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
              <style>
                body { 
                  font-family: 'Inter', sans-serif; 
                  padding: 20mm; 
                  margin: 0;
                  color: #000; 
                  line-height: 1.5;
                  font-size: 11pt;
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  overflow-wrap: break-word;
                  -webkit-font-smoothing: antialiased;
                }
                @media print {
                  @page {
                    margin: 0;
                    size: auto;
                  }
                  body {
                    padding: 20mm;
                    margin: 0;
                  }
                }
              </style>
            </head>
            <body>${newResume}</body>
          </html>
        `);
        w.document.close();
        
        // Small delay to ensure font loads
        setTimeout(() => {
            w.focus();
            w.print();
            w.close();
        }, 250);
    }
  };

  return (
    <div className="w-full max-w-7xl bg-white md:rounded-3xl shadow-soft p-0 h-full md:h-[85vh] flex flex-col animate-fade-in-up overflow-hidden border border-gray-100">
      
      {/* Header */}
      <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white/80 backdrop-blur-sm sticky top-0 z-20">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 display-font">Resume Tailor</h2>
          <p className="text-gray-500 text-sm">ATS-Optimized. Plain Text. Professional Standard.</p>
        </div>
        <div className="bg-purple-50 text-purple-600 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
          <Wand2 size={12} fill="currentColor" /> AI Powered
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-gray-50/50">
        
        {/* Left Column: Inputs */}
        <div className={`flex flex-col gap-4 p-6 overflow-y-auto transition-all duration-500 bg-white border-r border-gray-100 ${newResume ? 'md:w-1/3' : 'md:w-full'}`}>
           <div className="flex-1 flex flex-col min-h-[200px]">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                <Briefcase size={14} /> Target Job Description
              </label>
              <textarea
                className="flex-1 w-full bg-gray-50 rounded-xl p-4 text-sm border-none focus:ring-2 focus:ring-black/5 resize-none placeholder-gray-400 font-sans leading-relaxed"
                placeholder="Paste Job Description..."
                value={jd}
                onChange={(e) => setJd(e.target.value)}
              />
           </div>
           <div className="flex-1 flex flex-col min-h-[200px]">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                <FileText size={14} /> Current Resume
              </label>
              <textarea
                className="flex-1 w-full bg-gray-50 rounded-xl p-4 text-sm border-none focus:ring-2 focus:ring-black/5 resize-none placeholder-gray-400 font-sans leading-relaxed"
                placeholder="Paste current CV content..."
                value={resume}
                onChange={(e) => setResume(e.target.value)}
              />
           </div>
           
           {!newResume && (
             <Button onClick={handleTailor} disabled={loading || !jd || !resume} fullWidth className="mt-4 shadow-xl shadow-purple-200">
               {loading ? "Optimizing for ATS..." : "Generate Optimized Resume"}
             </Button>
           )}
        </div>

        {/* Right Column: Preview */}
        {newResume && (
          <div className="flex-1 flex flex-col animate-slide-in-right md:w-2/3 h-full overflow-hidden relative">
             
             {/* Toolbar */}
             <div className="p-4 flex items-center justify-between bg-white border-b border-gray-200 shadow-sm z-10">
                <div className="flex items-center gap-2">
                    <Button variant="ghost" onClick={() => setNewResume(null)} className="h-9 text-xs px-3">
                        Back to Edit
                    </Button>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="secondary" onClick={handleCopy} className="h-9 px-3 text-xs gap-2">
                       {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? 'Copied' : 'Copy'}
                    </Button>
                    <Button variant="secondary" onClick={handleDownloadTxt} className="h-9 px-3 text-xs gap-2">
                       <Download size={14} /> TXT
                    </Button>
                    <Button onClick={handlePrint} className="h-9 px-4 text-xs bg-black text-white gap-2 shadow-lg">
                       <Printer size={14} /> PDF / Print
                    </Button>
                </div>
             </div>
             
             {/* Document Preview Area */}
             <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-100/50 flex justify-center">
                <div 
                  ref={printRef}
                  className="bg-white w-full max-w-[210mm] min-h-[297mm] p-[20mm] shadow-xl text-gray-900 text-sm md:text-base leading-relaxed whitespace-pre-wrap break-words select-text border border-gray-200"
                  style={{
                    fontFamily: "'Inter', sans-serif"
                  }}
                >
                    {newResume}
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
