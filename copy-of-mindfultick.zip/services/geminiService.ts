
import { GoogleGenAI, Type } from "@google/genai";
import { GoalCategory, HistoryItem, InterviewAnalysis, InterviewReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMotivationalTip = async (category: GoalCategory, duration: number, intention: string): Promise<string> => {
  try {
    // Randomize the psychological lens for variety
    const frameworks = [
      "Stoicism (focus only on effort, ignore the outcome)",
      "Gamification (treat this session like a boss battle)",
      "Tiny Habits (just start for 2 minutes, then flow)",
      "Parkinson's Law (race against the clock to win)",
      "Mindfulness (observe the resistance, then let it go)",
      "Cognitive Reframing (this isn't work, it's a craft)"
    ];
    const selectedFramework = frameworks[Math.floor(Math.random() * frameworks.length)];

    const prompt = `
      User Context: Starting a ${duration}-min "${category}" session. Intention: "${intention}".
      
      Task: Generate a specific, psychological micro-challenge or insight using the lens of: ${selectedFramework}.
      
      Constraints:
      1. Max 20 words.
      2. Playful, witty, and charming.
      3. ABSOLUTELY NO MARKDOWN (No bold **, no italics _). Plain text only.
      4. End with one relevant emoji.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Focus on the process, not the outcome. You've got this! ✨";
  }
};

export const getCelebrationMessage = async (category: GoalCategory): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a short, high-energy congratulatory message (max 15 words) for finishing a ${category} session. Do not use markdown.`,
    });
    return response.text.trim();
  } catch (error) {
    return "Amazing work! Momentum is on your side. 🚀";
  }
};

export const analyzeHistory = async (history: HistoryItem[]): Promise<string> => {
  if (history.length === 0) return "Complete a few sessions first to unlock your profile!";

  try {
    const summary = history.map(h => ({
      cat: h.category,
      min: h.durationMinutes,
      intention: h.intention
    })).slice(0, 15);

    const prompt = `
      Analyze this user's recent focus session history: ${JSON.stringify(summary)}.
      Based on their habits, assign them a "Productivity Archetype" title and a 2-sentence psychological insight.
      Format: ## [Title] \n [Insight]
      Do not use bold markdown (**).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error(error);
    return "## The Mysterious Focus\nKeep tracking to reveal your true pattern.";
  }
};

export const analyzeInterviewContext = async (jd: string, resume: string): Promise<InterviewAnalysis | null> => {
  try {
    const prompt = `
      Act as an expert technical recruiter. Compare this Job Description with this Resume.
      JD: "${jd.slice(0, 3000)}"
      Resume: "${resume.slice(0, 3000)}"
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            companyName: { type: Type.STRING, description: "The name of the company from the JD. If not found, guess or use 'The Company'."},
            coreNeed: { type: Type.STRING, description: "One sentence summary of what the company really needs." },
            strongestMatch: { type: Type.STRING, description: "The strongest point in the resume for this job." },
            gapToProbe: { type: Type.STRING, description: "The biggest weakness or missing skill to ask about." },
          },
          required: ['companyName', 'coreNeed', 'strongestMatch', 'gapToProbe'],
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as InterviewAnalysis;
    }
    return null;
  } catch (error) {
    console.error("Analysis Error:", error);
    return null;
  }
};

export const getCompanyOverview = async (companyName: string): Promise<{text: string, sources: any[]}> => {
  if (!companyName || companyName === 'The Company') return { text: "No specific company data found.", sources: [] };
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Find recent news, culture overview, and key products for the company "${companyName}". Summarize in 3 bullet points for a job candidate.`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.map((c: any) => c.web ? { title: c.web.title, uri: c.web.uri } : null)
      .filter(Boolean) || [];

    return {
      text: response.text,
      sources: sources
    };
  } catch (e) {
    console.error("Search Error", e);
    return { text: "Could not fetch company data.", sources: [] };
  }
}

export const gradeInterview = async (transcript: {role: string, text: string}[]): Promise<InterviewReport | null> => {
  try {
    const prompt = `
      You are an interview coach. Review this transcript.
      Transcript: ${JSON.stringify(transcript)}
      Rate the candidate from 0-100 based on clarity, relevance, and confidence.
      Provide 3 specific strengths, 3 actionable improvements, and 3 suggested specific actions to take next.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER, description: "Score out of 100" },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedActions: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['score', 'strengths', 'improvements', 'suggestedActions'],
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as InterviewReport;
    }
    return null;
  } catch (error) {
    console.error("Grading Error:", error);
    return null;
  }
};

export const tailorResume = async (jd: string, oldResume: string): Promise<string> => {
  try {
    const prompt = `
      Act as a strict ATS (Applicant Tracking System) Specialist and Professional Resume Writer.
      
      JOB DESCRIPTION:
      "${jd.slice(0, 2000)}"
      
      CANDIDATE RESUME:
      "${oldResume.slice(0, 2000)}"
      
      TASK:
      Rewrite the resume to strictly target the Job Description.
      
      CRITICAL FORMATTING RULES (DO NOT IGNORE):
      1. OUTPUT PLAIN TEXT ONLY.
      2. DO NOT USE MARKDOWN (No **, No __, No #, No italics).
      3. Use UPPERCASE for section headers (e.g., EXPERIENCE, SKILLS).
      4. Use simple hyphens (-) for bullet points.
      5. Use a standard linear layout (No columns).
      6. Do not include any conversational text like "Here is your resume". Just output the resume content.
      
      CONTENT RULES:
      - Integrate keywords from the JD naturally.
      - Quantify achievements where possible based on the input.
      - Keep it professional and concise.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Resume Tailor Error:", error);
    return "Could not generate resume. Please try again.";
  }
};
