import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

// user text is usually cumulative (replace), model text is usually chunks (append)
export type TranscriptCallback = (sender: 'user' | 'model', text: string, mode: 'append' | 'replace') => void;

export class LiveClient {
  private ai: GoogleGenAI;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private inputNode: ScriptProcessorNode | null = null;
  private outputNode: GainNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private sessionPromise: Promise<any> | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  
  public isConnected = false;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async connect(onDisconnect: () => void, systemInstruction?: string, onTranscript?: TranscriptCallback) {
    if (this.isConnected) return;

    try {
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      if (this.inputAudioContext.state === 'suspended') {
        await this.inputAudioContext.resume();
      }
      if (this.outputAudioContext.state === 'suspended') {
        await this.outputAudioContext.resume();
      }

      this.outputNode = this.outputAudioContext.createGain();
      this.outputNode.connect(this.outputAudioContext.destination);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const defaultInstruction = "You are a helpful and motivating productivity coach. Keep responses concise, warm, and encouraging. Do not use markdown formatting like bold (**).";

      const config = {
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: async () => {
            console.log("Live session connected");
            this.isConnected = true;
            this.startInputStream(stream);
          },
          onmessage: (message: LiveServerMessage) => {
            this.handleServerMessage(message, onTranscript);
          },
          onclose: () => {
            console.log("Live session closed");
            this.disconnect();
            onDisconnect();
          },
          onerror: (e: any) => {
            console.error("Live session error", e);
            this.disconnect();
            onDisconnect();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          // RE-ENABLED: This is required for user text to appear in the chat.
          inputAudioTranscription: {}, 
          outputAudioTranscription: {}, 
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          // Reverted to string to avoid "Invalid Argument" with this specific SDK version/model combo
          systemInstruction: systemInstruction || defaultInstruction,
        },
      };

      this.sessionPromise = this.ai.live.connect(config);
      await this.sessionPromise;
      
    } catch (e) {
      console.error("Failed to connect live session", e);
      this.disconnect();
      throw e;
    }
  }

  sendText(text: string) {
    if (!this.sessionPromise) return;
    this.sessionPromise.then(session => {
        try {
            session.sendRealtimeInput({
                clientContent: {
                    turns: [{ role: 'user', parts: [{ text }] }],
                    turnComplete: true
                }
            });
        } catch (e) {
            console.warn("Failed to send text trigger", e);
        }
    });
  }

  private startInputStream(stream: MediaStream) {
    if (!this.inputAudioContext) return;

    this.sourceNode = this.inputAudioContext.createMediaStreamSource(stream);
    this.inputNode = this.inputAudioContext.createScriptProcessor(4096, 1, 1);
    
    this.inputNode.onaudioprocess = (e) => {
      if (!this.isConnected || !this.sessionPromise) return;

      const inputData = e.inputBuffer.getChannelData(0);
      const pcmData = this.floatTo16BitPCM(inputData);
      const base64 = this.arrayBufferToBase64(pcmData);

      this.sessionPromise.then((session) => {
        try {
          session.sendRealtimeInput({
            media: {
              mimeType: 'audio/pcm;rate=16000',
              data: base64
            }
          });
        } catch (err) {
          console.warn("Error sending audio frame", err);
        }
      });
    };

    this.sourceNode.connect(this.inputNode);
    // Mute input to avoid feedback loop
    const muteNode = this.inputAudioContext.createGain();
    muteNode.gain.value = 0;
    muteNode.connect(this.inputAudioContext.destination);
    this.inputNode.connect(muteNode);
  }

  private async handleServerMessage(message: LiveServerMessage, onTranscript?: TranscriptCallback) {
    const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (audioData) {
      if (!this.outputAudioContext || !this.outputNode) return;
      try {
        const arrayBuffer = this.base64ToArrayBuffer(audioData);
        const audioBuffer = await this.decodeAudioData(arrayBuffer, this.outputAudioContext);
        this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext.currentTime);
        const source = this.outputAudioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(this.outputNode);
        source.start(this.nextStartTime);
        this.nextStartTime += audioBuffer.duration;
        this.sources.add(source);
        source.onended = () => this.sources.delete(source);
      } catch (e) {
        console.error("Error decoding audio", e);
      }
    }

    if (message.serverContent?.interrupted) {
      this.sources.forEach(source => { try { source.stop(); } catch (e) {} });
      this.sources.clear();
      this.nextStartTime = 0;
    }

    if (onTranscript) {
       const modelText = message.serverContent?.modelTurn?.parts?.[0]?.text;
       if (modelText) {
          onTranscript('model', modelText, 'append');
       }
       const userTranscript = message.serverContent?.inputTranscription?.text;
       if (userTranscript) {
          onTranscript('user', userTranscript, 'replace');
       }
    }
  }

  disconnect() {
    this.isConnected = false;
    this.sources.forEach(s => { try { s.stop(); } catch (e) {} });
    this.sources.clear();
    
    if (this.sessionPromise) {
        this.sessionPromise.then(session => {
            try { session.close(); } catch(e) { console.warn("Error closing session", e); }
        }).catch(() => {});
        this.sessionPromise = null;
    }

    if (this.sourceNode) { try { this.sourceNode.disconnect(); } catch(e) {} this.sourceNode = null; }
    if (this.inputNode) { try { this.inputNode.disconnect(); } catch(e) {} this.inputNode = null; }
    if (this.inputAudioContext) { try { this.inputAudioContext.close(); } catch(e) {} this.inputAudioContext = null; }
    if (this.outputAudioContext) { try { this.outputAudioContext.close(); } catch(e) {} this.outputAudioContext = null; }
  }

  private floatTo16BitPCM(input: Float32Array): ArrayBuffer {
    const buffer = new ArrayBuffer(input.length * 2);
    const output = new DataView(buffer);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
    return buffer;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  private async decodeAudioData(data: ArrayBuffer, ctx: AudioContext): Promise<AudioBuffer> {
    const int16 = new Int16Array(data);
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768.0;
    }
    const buffer = ctx.createBuffer(1, float32.length, 24000);
    buffer.getChannelData(0).set(float32);
    return buffer;
  }
}