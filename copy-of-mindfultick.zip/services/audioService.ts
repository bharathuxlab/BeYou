// A simple synthesizer to create pleasant UI sounds without external assets
class AudioService {
  private context: AudioContext | null = null;
  private masterGain: GainNode | null = null;

  private init() {
    if (!this.context) {
      this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.context.createGain();
      this.masterGain.gain.value = 0.3; // Master volume
      this.masterGain.connect(this.context.destination);
    }
  }

  private playTone(freq: number, type: OscillatorType, duration: number, startTime: number = 0) {
    if (!this.context || !this.masterGain) this.init();
    if (!this.context) return;

    const osc = this.context.createOscillator();
    const gain = this.context.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.context.currentTime + startTime);

    // Envelope
    gain.gain.setValueAtTime(0, this.context.currentTime + startTime);
    gain.gain.linearRampToValueAtTime(1, this.context.currentTime + startTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.01, this.context.currentTime + startTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain!);

    osc.start(this.context.currentTime + startTime);
    osc.stop(this.context.currentTime + startTime + duration + 0.1);
  }

  public playStart() {
    this.init();
    // Uplifting major triad
    this.playTone(440, 'sine', 1.5, 0); // A4
    this.playTone(554.37, 'sine', 1.5, 0.1); // C#5
    this.playTone(659.25, 'sine', 2.0, 0.2); // E5
  }

  public playPause() {
    this.init();
    // Gentle descend
    this.playTone(440, 'sine', 0.3, 0);
    this.playTone(392, 'sine', 0.5, 0.1);
  }

  public playResume() {
    this.init();
    // Gentle ascend
    this.playTone(392, 'sine', 0.3, 0);
    this.playTone(440, 'sine', 0.5, 0.1);
  }

  public playComplete() {
    this.init();
    // Victory chord (C Major 7) with shimmer
    const notes = [523.25, 659.25, 783.99, 987.77]; // C5, E5, G5, B5
    notes.forEach((freq, i) => {
      this.playTone(freq, 'triangle', 2.5, i * 0.1);
      this.playTone(freq * 2, 'sine', 3.0, i * 0.1 + 0.05); // Harmonics
    });
  }
}

export const audioService = new AudioService();