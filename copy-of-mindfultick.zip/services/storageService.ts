import { HistoryItem, TimerSession } from "../types";

const STORAGE_KEY = 'mindfultick_history_v1';

export const saveSession = (session: TimerSession): void => {
  const history = getHistory();
  const newItem: HistoryItem = {
    ...session,
    id: crypto.randomUUID(),
    completedAt: Date.now()
  };
  
  // Keep last 50 sessions to save space
  const updatedHistory = [newItem, ...history].slice(0, 50);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedHistory));
};

export const getHistory = (): HistoryItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error("Failed to load history", e);
    return [];
  }
};

export const clearHistory = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};